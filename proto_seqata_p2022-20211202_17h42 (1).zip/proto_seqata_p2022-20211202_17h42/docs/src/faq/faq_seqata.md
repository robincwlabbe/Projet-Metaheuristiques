# FAQ/astuces spécifique à l'utilisation du proto Seqata


Pas de détails supplémentaires pour l'instant : voir les fichiers d'introduction 
principaux :

- [Présentation du prototype](01_presentation_proto_seqata.html)
- [Organisation du code du projet `ORGANISATION_CODE`](02_organisation_code.html)
- [Utilisation en mode interactif (`MODE_INTERACTIF`)](03_mode_interactif.html)





