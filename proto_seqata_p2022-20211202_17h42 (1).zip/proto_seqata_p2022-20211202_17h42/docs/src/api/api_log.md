# API du module Log
```@meta
CurrentModule = Seqata.Log
```

```@docs
Log
```


todo


